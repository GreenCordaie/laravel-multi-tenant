<html>
    123
</html><?php /**PATH C:\Users\alldi\laravel-multi-tenant\resources\views/welcome.blade.php ENDPATH**/ ?>